package com.ict.project.service;

public interface SocialService {

}
