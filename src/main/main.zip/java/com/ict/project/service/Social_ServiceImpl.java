package com.ict.project.service;

import org.springframework.stereotype.Service;

@Service
public class Social_ServiceImpl implements SocialService{

}
